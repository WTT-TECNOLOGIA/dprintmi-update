import moment from 'moment';
import utils from '../utils.js';
import DB from '../db.js';

export default {

    // Obtem lista de devices
    async findAll(req, res) {
        const results = await DB().select(['ID as id', 'NAME as name', 'AETITLE as aetitle', 'MODALITY as modality', 'PARENTID as parentid']).table('dicomdevices').orderBy(['id']);
    
        let devices = [];
    
        for (let group of results) {
            if (!group.parentid) {
                devices.push(group);
    
                for (let device of results) {
                    if (group.id === device.parentid) {
                        devices.push(device);
                    }
                }
            }
        }
    
        res.json(devices);
    },

    // Obtem lista de modalidade atraves dos devices cadastrados
    async findAllModalities(req, res) {
        try {
            const modalities = await DB().distinct(['d.modality as id', 'm.description']).table('dicomdevices as d').innerJoin('modalities as m', 'd.modality', 'm.id').whereNotNull('d.modality').orderBy(['d.modality']);
            
            res.json(modalities);
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },

    // Salva ou atualiza o device recebido
    async save(req, res) {
        const trx = await DB().transaction();
        try {
    
            if (!req.body || !req.body.name) {
                throw new Error('O campo nome não foi informado');
            }
    
            let device = req.body;
    
            let rows;
    
            // normaliza campos obrigatorios
            device.name = device.name ? device.name.toUpperCase() : device.name;
            device.aetitle = device.aetitle ? device.aetitle.toUpperCase() : device.aetitle;
            device.modality = device.modality ? device.modality.toUpperCase() : device.modality;
    
            if (device.id) {
                rows = await DB().transacting(trx).from('dicomdevices').where('id', '=', device.id).update({ name: device.name, aetitle: device.aetitle, modality: device.modality }, ['id', 'name', 'aetitle', 'modality', 'parentid'], { includeTriggerModifications: true });
            } else {
                rows = await DB().transacting(trx).insert(device, ['id', 'name', 'aetitle', 'modality', 'parentid'], { includeTriggerModifications: true }).into('dicomdevices');
            }
    
            if (rows.length) {
                device = rows[0];
            }
        
            trx.commit();
            res.json(device);
        } catch (err) {
            trx.rollback();
            res.status(400).json({ message: err.message });
        }
    },

    // Remove device pelo ID passado por parametro
    async delete(req, res) {
        const trx = await DB().transaction();
        try {
            
            if (!req.params.id) {
                throw new Error('Informe o ID do equipamento.');
            }
    
            const rows = await DB().transacting(trx).select(['id', 'parentid']).from('dicomdevices').where('id', '=', req.params.id);
            if (!rows.length) {
                res.status(404).json({ message: 'Registro não localizado!' });
            }
    
            const row = rows[0];
    
            if (!row.parentid) {
                await DB().transacting(trx).from('dicomdevices').where('parentid', row.id).delete();
            }
    
            await DB().transacting(trx).from('dicomdevices').where('id', '=', row.id).delete();
            
            trx.commit();
            res.json({ message: `Registro ${req.params.id} removido com sucesso.` });
        } catch (err) {
            trx.rollback();
            res.status(400).json({ message: err.message });
        }
    },
};
