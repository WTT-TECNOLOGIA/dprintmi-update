import { Router } from 'express';
import { authenticated, hasRoles, hasPermissions, isAdmin } from './middlewares.js';
import pagesCtrl from './home/home.ctrl.js';
import systemCtrl from './system/system.ctrl.js';
import userCtrl from './users/users.ctrl.js';
import printsCtrl from './prints/prints.ctrl.js';
import devicesCtrl from './devices/devices.ctrl.js';
import modalitiesCtrl from './modalities/modalities.ctrl.js';
import groupsCtrl from './groups/groups.ctrl.js'

var appRoutes = Router();
var apiRoutes = Router();

// registra as rotas da aplicacao
appRoutes.get('/', pagesCtrl.home);
apiRoutes.get('/', pagesCtrl.goToHome);

// info obtem informacoes uteis
apiRoutes.get('/system', systemCtrl.getInfo);
apiRoutes.get('/system/update', systemCtrl.checkVersion);
apiRoutes.post('/system/update', systemCtrl.updateVersion);
apiRoutes.get('/system/reload', systemCtrl.reload);
apiRoutes.get('/system/reload/check', systemCtrl.checkReload);
apiRoutes.get('/system/settings', systemCtrl.getConfig);
apiRoutes.post('/system/settings', systemCtrl.saveConfig);
apiRoutes.post('/system/db/check', authenticated, systemCtrl.checkDBConn);
apiRoutes.get('/system/permissions', authenticated, systemCtrl.getPermissions);

// users routes (isAdmin | hasRoles('USER') | hasPermissions('USER_UPDATE'))
apiRoutes.post('/users', authenticated, userCtrl.findAll);
apiRoutes.post('/users/save', authenticated, userCtrl.save);
apiRoutes.delete('/users/:id', authenticated, userCtrl.remove);
apiRoutes.post('/users/login', userCtrl.login);
apiRoutes.get('/users/check', authenticated, userCtrl.checkToken);
apiRoutes.get('/users/groups/:id/permissions', authenticated, userCtrl.groupPermissions);
apiRoutes.get('/users/:id/groups', authenticated, userCtrl.userGroups);
apiRoutes.post('/users/:id/groups', authenticated, userCtrl.addGroup);
apiRoutes.delete('/users/:id/groups/:groupid', authenticated, userCtrl.removeGroup);
apiRoutes.get('/users/:id/groups/:groupid/permissions', authenticated, userCtrl.userGroupPermissions);
apiRoutes.get('/users/:id/permissions', authenticated, userCtrl.userPermissions);
apiRoutes.post('/users/:id/permissions', authenticated, userCtrl.saveUserPermissions);
apiRoutes.put('/users/:id/permissions/reset', authenticated, userCtrl.resetPermissions);
apiRoutes.get('/users/:id/modalities', authenticated, userCtrl.findUserModalities);
apiRoutes.post('/users/:id/modalities', authenticated, userCtrl.saveUserModality);

// groups and permissions routes
apiRoutes.get('/groups', authenticated, groupsCtrl.findAll);
apiRoutes.post('/groups', authenticated, groupsCtrl.save);
apiRoutes.delete('/groups/:id', authenticated, groupsCtrl.remove);
apiRoutes.get('/groups/:id/permissions', authenticated, groupsCtrl.findPermissionsByGroup);
apiRoutes.post('/groups/:id/permissions', authenticated, groupsCtrl.savePermissionsByGroup);
apiRoutes.get('/groups/:id/modalities', authenticated, groupsCtrl.findGroupModalities);
apiRoutes.post('/groups/:id/modalities', authenticated, groupsCtrl.saveModality);

// devices routes
apiRoutes.get('/devices', authenticated, devicesCtrl.findAll);
apiRoutes.post('/devices', authenticated, devicesCtrl.save);
apiRoutes.delete('/devices/:id', authenticated, devicesCtrl.delete);
apiRoutes.get('/devices/modalities', authenticated, devicesCtrl.findAllModalities);

// modalities routes
apiRoutes.get('/modalities', authenticated, modalitiesCtrl.findAll);

// prints routes
apiRoutes.get('/prints/search', authenticated, printsCtrl.prints);

export {
    appRoutes,
    apiRoutes
};
