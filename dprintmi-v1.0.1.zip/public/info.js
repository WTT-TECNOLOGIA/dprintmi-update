window.appInfo = {
    api: 'http://192.168.0.3:3000'
};
