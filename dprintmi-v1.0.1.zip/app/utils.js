import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import * as uuid from 'uuid';
import http from 'axios';
import userDAO from './users/users.dao.js';

const appHash = 'd4973aca-be58-40b3-b18b-73b8548c75cb';

export default {
    getPkg: async function() {
        const pkg = JSON.parse(fs.readFileSync(path.resolve(`./package.json`), 'utf8'));

        return {
            title: pkg.title || '',
            description: pkg.description || '',
            version: pkg.version || '0.0.1'
        };
    },

    loadDataFile: async function() {
        const dataFile = path.resolve('./bin/settings.dll');

        if (!fs.existsSync(dataFile)) {
            const defaultData = {
                server: {
                    port: 3005
                },
                database: {
                    checked: false,
                    client: 'mssql',
                    connection: {
                        user: 'sa',
                        password: '',
                        host: '127.0.0.1',
                        port: 1433,
                        database: 'WTTPSERVER'
                    }
                },
                dserver: {
                    mag0: '',
                    mag1: '',
                    mag2: '',
                    mag3: '',
                },
                device: null
            }

            fs.writeFileSync(path.resolve('./bin/settings.dll'), this.encrypt(JSON.stringify(defaultData, null, 2)));
        }
        
        const data = fs.readFileSync(dataFile);
        // return JSON.parse(data.toString());
        return JSON.parse(this.decrypt(data.toString()));
    },

    saveDataFile: async function(data) {
        // fs.writeFileSync(path.resolve('./bin/settings.dll'), JSON.stringify(data, null, 2));
        fs.writeFileSync(path.resolve('./bin/settings.dll'), this.encrypt(JSON.stringify(data, null, 2)));
        return data;
    },

    async checkVersion() {
        try {
            const res = await http.get('https://raw.githubusercontent.com/WTT-TECNOLOGIA/dprintmi-update/main/version.json');
            return res.data;
        } catch (err) {
            return err;
        }
    },

    getAppHash() {
        return appHash;
    },

    newToken: function(data) {
        return jwt.sign(data, appHash, {
            expiresIn: '150 days'
        });
    },

    hasPermission: function(req, res, next) {
        const authorization = req.headers['authorization'];
        
        if (!authorization) {
            return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' });
        }
        
        const partsToken = authorization.split(' ');
        const prefixToken = partsToken[0].trim();
        const hashToken = partsToken[1].trim();

        if ((!prefixToken || prefixToken !== 'Bearer') || !hashToken) {
            return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' });
        }

        jwt.verify(hashToken, appHash, (err, user) => {
            if (err) {
                return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' }) ;
            }
            req.user = user;
            next();
        });
    },

    dbDriverName: function(driver) {
        switch (driver) {
            case 'mssql':
                return 'MS SQL Server';
            case 'pg':
                return 'PostgreSQL';
            case 'mysql':
                return 'MySQL';
            case 'mysql2':
                return 'MariaDB';
            case 'oracledb':
                return 'Oracle';
            default:
                return 'MS SQL Server';
        }
    },

    getUUID: function() {
        return uuid.v4();
    },

    base64Encode: function(str) {
        return Base64.encode(str);
    },

    base64Decode: function(str) {
        return Base64.decode(str);
    },

    sha256: function(str) {
        // return crypto.createHash('sha256').update(str).digest('base64');
        return crypto.createHash('sha256').update(str).digest('hex');
    },

    encrypt: function(text) {
        var cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from('d4973aca-be58-b18b-73b8548c75cb5'), Buffer.from('b18b73b8548c75cb'));
        var crypted = cipher.update(text, 'utf8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
    },

    decrypt: function(text) {
        var decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from('d4973aca-be58-b18b-73b8548c75cb5'), Buffer.from('b18b73b8548c75cb'));
        var dec = decipher.update(text, 'hex', 'utf8');
        dec += decipher.final('utf8');
        return dec;
    },

    capitalize: function(text) {
        return text.replace(/\w/, c => c.toUpperCase());
    },

    isAdmin(user) {
        return ['DEVELOPER', 'SUPPORT', 'ADMINISTRATOR'].indexOf(user.type) > -1;
    },

    hasRoles(user, ...roles) {
        return roles.indexOf(user.type) > -1;
    },

    async hasPermissions(user, ...permissions) {
        const userPermissions = await userDAO.findPermissionsByUser(user);

        for (let permission of permissions) {
            if (userPermissions.indexOf(permission) > -1) {
                return true;
            }
        }
        
        return false;
    },
}