import jwt from 'jsonwebtoken';
import moment from 'moment';
import utils from './utils.js';
import DB from './db.js';

// Verifica se o usuario esta logado validando token recebido
export function authenticated(req, res, next) {
    const authorization = req.headers['authorization'];
    
    if (!authorization) {
        return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' });
    }
    
    const partsToken = authorization.split(' ');
    const prefixToken = partsToken[0].trim();
    const hashToken = partsToken[1].trim();

    if ((!prefixToken || prefixToken !== 'Bearer') || !hashToken) {
        return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' });
    }

    jwt.verify(hashToken, utils.getAppHash(), (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' }) ;
        }
        req.user = user;
        next();
    });
}

// Verifica se o usuario tem a permissao exigida para entrar na rota
export function hasRoles(...roles) {
    return (req, res, next) => {
        
        if (!utils.hasRoles(req.user, ...roles)) {
            return res.status(403).json({ message: 'Sua credencial não foi autorizada a acessar a área solicitada.' });
        }
        
        next();
    }
}

// Verifica se o usuario tem a permissao exigida para entrar na rota
export function hasPermissions(...permissions) {
    return async(req, res, next) => {

        if (!await utils.hasPermissions(req.user, ...permissions)) {
            return res.status(403).json({ message: 'Sua credencial não foi autorizada a acessar a área solicitada.' });
        }
        
        next();
    }
}

// Verifica se o usuario é admin para entrar na rota
export function isAdmin(req, res, next) {
    
    if (!utils.isAdmin(req.user)) {
        return res.status(403).json({ message: 'Sua credencial não foi autorizada a acessar a área solicitada.' });
    }
    
    next();
}

export default {
    authenticated,
    hasPermissions,
};
