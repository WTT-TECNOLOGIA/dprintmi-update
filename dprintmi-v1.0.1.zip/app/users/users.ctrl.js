import moment from 'moment';
import utils from '../utils.js';
import DB from '../db.js';
import userDAO from './users.dao.js';

export default {

    // Autentica usuario no sistema
    async login(req, res) {
        try {
            const username = req.body.username;
            const password = req.body.pwd;
            
            if (!username || !password) {
                return res.status(401).json({ message: 'Desculpe! Credencial Inválida!' });
            }
    
            let user;
        
            // se usuario de manutencao, atribui perfil "CONFIG" e direciona o usuario
            if (username.toUpperCase() === 'SUPORTE' && password === `wtt@${moment().format('DD')}`) {
                user = { 
                    id: '0', 
                    username: 'SUPORTE',
                    fullname: 'SUPORTE', 
                    socialname: 'SUPORTE', 
                    status: 'ACTIVE',
                    type: 'CONFIG',
                    group: null,
                    groups: [],
                    permissions: [] 
                };
        
                user.token = utils.newToken(user);
                
                return res.json(user);
            }
    
            // se a conexao com banco de dados estive ok, consulta login no banco do docintime
            const settings = await utils.loadDataFile();
            if (!settings.database.checked) {
                throw new Error('A conexão com banco de dados não foi validada, por favor, confira as configurações.');
            }
    
            // autentica usuario pelo banco do docintime
            const rows = await DB().select(['u.username', 'u.fullname', 'u.email', 'u.userstatus', 'u.usertype', 'u.profile as group_id', 'ug.description as group_description']).table('users as u').leftOuterJoin('usergroups as ug', 'u.profile', 'ug.groupid').whereRaw('lower(u.username) = lower(?) and pwd = ?', [username, utils.sha256(password.toUpperCase())]);
            
            if (!rows.length) {
                throw new Error('Sua credencial não foi autorizada');
            }
            
            user = rows[0];
            
            user = {
                id: utils.getUUID(),
                username: user.username,
                fullname: user.fullname,
                socialname: user.fullname ? user.fullname.split(' ')[0] : user.fullname,
                status: user.userstatus,
                type: user.usertype,
                group: { id: user.group_id, description: user.group_description },
            };
            
            user.token = utils.newToken(user);
            
            // busca os grupos do usuario
            user.groups = await userDAO.findGroupsByUser(user);
    
            // busca permissoes do usuario
            user.permissions = await userDAO.findPermissionsByUser(user);
            
            return res.json(user);
        } catch (err) {
            return res.status(401).json({ message: err.message });
        }
    },

    // Valida token do usuario logado no sistema
    async checkToken(req, res) {
        
        if (!req.user) {
            return res.status(403).json({ message: 'Desculpe! O acesso não foi permitido, verifique sua credencial ou entre em contato com administrador do sistema.' });
        }

        if (req.user.type === 'CONFIG') {
            return res.json(req.user);
        }
    
        // adiciona os grupos do usuario
        req.user.groups = await userDAO.findGroupsByUser(req.user);
    
        // busca permissoes do usuario
        req.user.permissions = await userDAO.findPermissionsByUser(req.user);
    
        res.json(req.user);
    },

    // Obtem lista de usuarios cadastrados
    async findAll(req, res) {

        let q = DB().select(['username', 'fullname', 'profile', 'email', 'userstatus', 'usertype']);

        // usuario logado so pode ver usuarios do seu nivel para baixo
        switch (req.user.type) {
            case 'DEVELOPER':
                q.whereIn('usertype', ['DEVELOPER', 'SUPPORT', 'ADMINISTRATOR', 'USER']);
                break;
            case 'SUPPORT':
                q.whereIn('usertype', ['SUPPORT', 'ADMINISTRATOR', 'USER']);
                break;
            case 'ADMINISTRATOR':
                q.whereIn('usertype', ['ADMINISTRATOR', 'USER']);
                break;
            default:
                q.whereIn('usertype', ['USER']);
                break;
        }
    
        if (req.body && req.body.term) {
            const term = req.body.term.toLowerCase();
    
            q.orWhere(
                DB().raw('LOWER(username) like ?', `%${term}%`)
            );
            
            q.orWhere(
                DB().raw('LOWER(fullname) like ?', `%${term}%`)
            );
    
            q.orWhere(
                DB().raw('LOWER(email) like ?', `%${term}%`)
            );
            
            q.orWhere(
                DB().raw('LOWER(profile) like ?', `%${term}%`)
            );
        }
    
        let users = await q.from('users');
        
        res.json(users);
    },

    // Obtem lista dos grupos do usuario passado por parametro
    async userGroups(req, res) {
        try {
            
            if (!req.params.id) {
                throw new Error('Inform o ID do usuário');
            }
    
            const username = req.params.id.toUpperCase();
        
            let groups = await DB().select(['ug.groupid as id', 'g.description', 'g.profile', 'g.internal']).from('user_x_group as ug').innerJoin('usergroups as g', 'ug.groupid', 'g.groupid').where(
                DB().raw('UPPER(ug.username) = ?', username)
            ).orderBy(['g.groupid']);
            
            res.json(groups);
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Obtem lista de permissoes do grupo passado por paramentro
    async groupPermissions(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Inform o ID do grupo');
            }
    
            const groupid = req.params.id;
    
            let permissions = await DB().select(['p.permission']).from('usergroups as g').innerJoin('user_permissions as p', 'g.groupid', 'p.groupid').where(
                DB().raw('g.groupid = ?', [groupid])
            );
    
            permissions = permissions.map((item) => {
                return item.permission;
            });
            
            res.json(permissions);
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Obtem lista de permissoes dos grupos do usuario
    async userGroupPermissions(req, res) {
        try {
    
            if (!req.params.id || !req.params.groupid) {
                throw new Error('Inform o ID do usuário e ID do grupo');
            }
    
            const username = req.params.id.toUpperCase();
            const groupid = req.params.groupid;
    
            let permissions = await DB().select(['p.permission']).from('user_x_group as ug').innerJoin('usergroups as g', 'ug.groupid', 'g.groupid').innerJoin('user_permissions as p', 'ug.groupid', 'p.groupid').where(
                DB().raw('UPPER(ug.username) = ? and ug.groupid = ? and p.username is null', [username, groupid])
            ).unionAll(function() {
                this.select(['p.permission']).from('user_permissions as p').where(
                    DB().raw('UPPER(p.username) = ? and p.groupid = ?', [username, groupid])
                );
            });
    
            permissions = permissions.map((item) => {
                return item.permission;
            });
            
            res.json(permissions);
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Obtem lista de permissoes do usuario passado por parametro
    async userPermissions(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Inform o ID do usuário');
            }
    
            const username = req.params.id.toUpperCase();
    
            const permissions = await userDAO.findPermissionsByUsername(username);
            
            res.json(permissions);
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Salva ou atualiza as permissoes do usuario
    async saveUserPermissions(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Inform o ID do usuário');
            }
    
            const username = req.body.username.toUpperCase();
            const permissions = req.body.permissions;
    
            for (let permission of permissions) {
                const results = await DB().select(['id']).from('user_permissions').where({ username: username, permission: permission.id });
    
                if (results.length) {
                    await DB().from('user_permissions').where({ id: results[0].id }).update({ allow: permission.selected });
                } else {
                    await DB().from('user_permissions').insert({ username: username, permission: permission.id, allow: permission.selected });
                }
            }
            
            res.json({ message: 'As informações foram salvas com sucesso.' });
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Obtem lista de permissoes das modalidades do usuario
    async findUserModalities(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Inform o ID do usuário');
            }
    
            const username = req.params.id.toUpperCase();
    
            let permissions = await DB().distinct(['p.permission']).from('user_x_group as ug').innerJoin('usergroups as g', 'ug.groupid', 'g.groupid').innerJoin('user_permissions as p', 'ug.groupid', 'p.groupid').where(
                DB().raw(`UPPER(ug.username) = ? and p.username is null and p.permission like 'MODALITY_%' and p.permission not in (select up.permission from user_permissions as up where up.username = ug.username and p.permission like 'MODALITY_%')`, [username])
            ).unionAll(function() {
                this.distinct(['p.permission']).from('user_permissions as p').where(
                    DB().raw(`UPPER(p.username) = ? and p.permission like 'MODALITY_%' and p.allow = '1'`, [username])
                );
            });
    
            permissions = permissions.map((item) => {
                return item.permission.split('_')[1];
            });
    
            res.json(permissions);
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Salva ou atualiza as permissoes de modalidades do usuario
    async saveUserModality(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Inform o ID do usuário');
            }
    
            const username = req.body.username.toUpperCase();
            const modality = req.body.modality;
            
            const rows = await DB().select(['id']).from('user_permissions').where({ username: username }).whereNull('groupid').andWhere({ permission: `MODALITY_${modality.id}` });
    
            if (rows.length) {
                await DB().from('user_permissions').where({ id: rows[0].id }).update({ allow: modality.selected });
            } else {
                await DB().from('user_permissions').insert({ username: username, permission: `MODALITY_${modality.id}`, allow: modality.selected });
            }
            
            res.json({ message: 'As informações foram salvas com sucesso.' });
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    async resetPermissions(req, res) {
        try {
            
            if (!req.params.id) {
                throw new Error('Inform o ID do usuário');
            }
    
            const username = req.params.id.toUpperCase();
    
            await DB().from('user_permissions').where({ username: username }).whereNull('groupid').delete();
    
            res.json({ message: 'As permissões foram redefinidas com sucesso.' });
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Adiciona grupo na lista do usuario
    async addGroup(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Informe os parâmetros exigidos');
            }
    
            const username = req.body.username.toUpperCase();
            const groupid = req.body.groupid;
    
            const results = await DB().select(['username', 'groupid']).from('user_x_group').where({ username: username, groupid: groupid });
            if (!results.length) {
                await DB().from('user_x_group').insert({ username: username, groupid: groupid }, [], { includeTriggerModifications: true });
            }
    
            const rows = await DB().select(['groupid as id', 'description', 'profile', 'internal']).from('usergroups').where({ groupid: groupid });
            if (rows.length) {
                return res.json(rows[0]);
            }
            
            throw new Error('Ocorreu um erro inesperado ao retornar o grupo');
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Remove grupo da lista do usuario
    async removeGroup(req, res) {
        try {
    
            if (!req.params.id || !req.params.groupid) {
                throw new Error('Informe os parâmetros exigidos');
            }
    
            const username = req.params.id.toUpperCase();
            const groupid = req.params.groupid;
    
            await DB().from('user_x_group').where({ username: username, groupid: groupid }).delete();
    
            res.json({ message: 'Grupo removido com sucesso.' });
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Salva ou atualiza o usuario
    async save(req, res) {
        const trx = await DB().transaction();
        try {
            let user = req.body;
    
            if (!user.username || !user.fullname || !user.usertype || !user.userstatus) {
                throw new Error('Informe os campos exigidos.');
            }

            // console.log('>>>> Permissions:', await utils.hasPermissions(req.user, 'ALL', 'USER_CREATE', 'USER_UPDATE') );
            // console.log('>>>> Roles:', utils.hasRoles(req.user, 'ADMINISTRATOR') );
            // console.log('>>>> Admin:', utils.isAdmin(req.user) );

            if (!await utils.hasPermissions(req.user, 'ALL', 'USER_CREATE', 'USER_UPDATE')) {
                return res.status(403).json({ message: 'Sua credencial não foi autorizada para acessar a área solicitada.' });
            }

            user.username = user.username.toUpperCase();
            user.fullname = user.fullname.toUpperCase();
            user.email = user.email ? user.email.toLowerCase() : user.email;
    
            let rows = await DB().transacting(trx).select(['username', 'fullname', 'email', 'profile', 'userstatus']).from('users').whereRaw('upper(username) = upper(?)', [user.username]);
            if (!rows.length) {
                rows = await DB().transacting(trx).from('users').insert({ username: user.username, fullname: user.fullname, profile: user.profile, email: user.email, userstatus: user.userstatus, usertype: user.usertype }, ['username', 'fullname', 'profile', 'email', 'userstatus', 'usertype'], { includeTriggerModifications: true });
            } else {
                rows = await DB().transacting(trx).from('users').whereRaw('upper(username) = upper(?)', [user.username]).update({ fullname: user.fullname, profile: user.profile, email: user.email, userstatus: user.userstatus, usertype: user.usertype }, ['username', 'fullname', 'profile', 'email', 'userstatus', 'usertype'], { includeTriggerModifications: true });
            }
    
            if (rows.length) {
                user = rows[0];
            }
            
            trx.commit();
            res.json(user);
        } catch (err) {
            trx.rollback();
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    // Remove usuario
    async remove(req, res) {
        try {

            if (!req.params.id) {
                throw new Error('Informe os campos exigidos.');
            }

            const username = req.params.id;

            if (req.params.id.toUpperCase() === req.user.username.toUpperCase()) {
                throw new Error('Você está tentando remover seu próprio usuário, por segurança a operação foi cancelada.')
            }

            if (!utils.hasRoles(req.user, 'DEVELOPER', 'SUPPORT')) {
                return res.status(403).json({ message: 'Sua credencial não foi autorizada para executar essa operação.' });
            }

            let rows = await userDAO.userExists(username);
            if (!rows.length) {
                return res.status(404).json({ message: 'Usuário não encontrado.' });
            }

            await userDAO.remove(rows[0]);
            
            res.json({ message: 'Usuário excluído com sucesso.' });
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },
};
