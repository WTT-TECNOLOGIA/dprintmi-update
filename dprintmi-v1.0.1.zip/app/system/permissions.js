export default [
    {
        id: 'ALL',
        text: "Todos",
        selected: false,
        expanded: true,
        items: [
            {
                id: 'USER',
                text: "Gerenciar Usuários",
                selected: false,
                expanded: true,
                items: [
                    {
                        id: 'USER_CREATE',
                        text: "Criar novos usuários",
                        selected: false,
                    },
                    {
                        id: 'USER_UPDATE',
                        text: "Alterar dados do usuário",
                        selected: false
                    },
                    {
                        id: 'USER_DELETE',
                        text: "Excluir usuários",
                        selected: false
                    },
                    {
                        id: 'USER_RESET_PWD',
                        text: "Alterar senha dos usuários",
                        selected: false
                    },
                    {
                        id: 'USER_GROUP_CREATE',
                        text: "Criar grupos e permissões",
                        selected: false,
                    },
                    {
                        id: 'USER_CHANGE_PERMISSIONS',
                        text: "Alterar permissões do usuário",
                        selected: false,
                    },
                    {
                        id: 'USER_CHANGE_MODALITIES',
                        text: "Alterar permissões de modalidades",
                        selected: false,
                    }
                ]
            },
            {
                id: 'DEVICE',
                text: 'Gerenciar Equipamentos',
                selected: false,
                expanded: true,
                items: [
                    {
                        id: 'DEVICE_CREATE',
                        text: 'Criar novos equipamentos',
                        selected: false
                    },
                    {
                        id: 'DEVICE_UPDATE',
                        text: 'Alterar dados do equipamento',
                        selected: false
                    },
                    {
                        id: 'DEVICE_DELETE',
                        text: 'Excluir equipamentos',
                        selected: false
                    },
                    {
                        id: 'DEVICE_ALTERNATE',
                        text: 'Escolher e alternar equipamento',
                        selected: false
                    }
                ]
            }
        ]
    }
];
