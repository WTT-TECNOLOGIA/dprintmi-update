import utils from '../utils.js';
import shortid from 'shortid';
import DB, { database } from '../db.js';
import path from 'path';
import fs from 'fs';
import permissionsType from './permissions.js';
import http from 'axios';

export default {

    // Obtem informacoes globais da aplicacao
    async getInfo(req, res) {
        const info = await utils.getPkg();
        res.json(info);
    },

    // Obtem versao do repositorio
    async checkVersion(req, res) {
        const data = await utils.checkVersion();
        res.json(data);
    },

    // Atualiza versao do sistema
    async updateVersion(req, res) {
        console.log('>>>> Update Version!!!');

        res.json({ message: 'OK' })
    },

    // Verifica se tem solicitacao para recarregar a aplicacao
    checkReload(req, res) {
        if (req.query.id) {
            const pidFile = path.resolve(`./bin/pid/${req.query.id}.json`);
    
            if (fs.existsSync(pidFile)) {
                fs.unlinkSync(pidFile);
            }
        }
        res.json({ reloaded: true });
    },

    // Recarrega a aplicacao
    reload(req, res) {
        const message = { id: shortid.generate(), action: 'RESTART' };
        
        process.send(message);
        
        res.json(message);
    },

    // Obtem configuracoes globais
    async getConfig(req, res) {
        const data = await utils.loadDataFile();
        return res.json(data);
    },

    // Salva as configuracoes criptografadas
    async saveConfig(req, res) {
        const settings = req.body;
    
        // normaliza os campos necessarios
        settings.database.connection.port = settings.database.connection.port ? parseInt(settings.database.connection.port) : settings.database.connection.port;
    
        const data = await utils.saveDataFile(settings);
        return res.json(data);
    },

    // Valida conexao com banco de dados configurado
    async checkDBConn(req, res) {
        const settings = req.body;
    
        const status = await database.check(settings);
        if (!status.checked) {
            return res.status(400).json(status);
        }
    
        return res.json(status);
    },

    // Obtem arvore de permissoes do sistema
    async getPermissions(req, res) {
        res.json(permissionsType);
    }
};
