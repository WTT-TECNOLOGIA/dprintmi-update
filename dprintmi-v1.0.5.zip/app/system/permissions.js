export default [
    {
        id: 'ALL',
        text: "Todos",
        selected: false,
        expanded: true,
        items: [
            {
                id: 'DPRINT_OPERATOR',
                text: 'DPrintMI - Operador',
                selected: false,
                expanded: true,
                items: [
                    {
                        id: 'DPRINT_ASSOCIATE',
                        text: "Associar impressos ao exame realizado",
                        selected: false,
                    },
                    {
                        id: 'DPRINT_DESASSOCIATE',
                        text: "Desassociar impressos do exame",
                        selected: false,
                    },
                    {
                        id: 'DPRINT_CHECKOUT',
                        text: "Liberar exames para entrega",
                        selected: false,
                    },
                    {
                        id: 'DPRINT_DEVICE_ALTERNATE',
                        text: 'Selecionar ou alternar de equipamento',
                        selected: false
                    }
                ]
            },
            {
                id: 'SETTINGS',
                text: 'Configurações',
                selected: false,
                expanded: true,
                items: [
                    {
                        id: 'DEVICE_TAB',
                        text: "Permitir acesso na aba equipamentos",
                        selected: false,
                    },
                    {
                        id: 'USER_TAB',
                        text: "Permitir acesso na aba de usuários",
                        selected: false,
                    },
                    {
                        id: 'USER_GROUP_TAB',
                        text: "Permitir acesso na aba grupos e permissões",
                        selected: false,
                    },
                ]
            },
            {
                id: 'DEVICE',
                text: 'Equipamentos',
                selected: false,
                expanded: true,
                items: [
                    {
                        id: 'DEVICE_CREATE',
                        text: 'Criar novos equipamentos',
                        selected: false
                    },
                    {
                        id: 'DEVICE_UPDATE',
                        text: 'Alterar dados do equipamento',
                        selected: false
                    },
                    {
                        id: 'DEVICE_DELETE',
                        text: 'Excluir equipamentos',
                        selected: false
                    }
                ]
            },
            {
                id: 'USER',
                text: "Usuários",
                selected: false,
                expanded: true,
                items: [
                    {
                        id: 'USER_CREATE',
                        text: "Criar novos usuários",
                        selected: false,
                    },
                    {
                        id: 'USER_UPDATE',
                        text: "Alterar dados do usuário",
                        selected: false
                    },
                    {
                        id: 'USER_DELETE',
                        text: "Excluir usuários",
                        selected: false
                    },
                    {
                        id: 'USER_RESET_PWD',
                        text: "Alterar senha dos usuários",
                        selected: false
                    },
                    {
                        id: 'USER_CHANGE_PERMISSIONS',
                        text: "Alterar permissões do usuário",
                        selected: false,
                    },
                    {
                        id: 'USER_CHANGE_MODALITIES',
                        text: "Alterar modalidades do usuário",
                        selected: false,
                    },
                    {
                        id: 'USER_GROUP_CREATE',
                        text: "Criar grupos e permissões",
                        selected: false,
                    },
                    {
                        id: 'USER_GROUP_UPDATE',
                        text: "Alterar grupos e permissões",
                        selected: false,
                    },
                    {
                        id: 'USER_GROUP_DELETE',
                        text: "Excluir grupos e permissões",
                        selected: false,
                    },
                ]
            },
        ]
    }
];
