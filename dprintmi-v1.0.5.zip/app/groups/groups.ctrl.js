import moment from 'moment';
import utils from '../utils.js';
import DB from '../db.js';

export default {
    async findAll(req, res) {
        try {
        
            const groups = await DB().select(['groupid as id', 'description', 'profile', 'internal']).from('usergroups').orderBy(['id']);
            
            res.json(groups);
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },

    async findPermissionsByGroup(req, res) {
        try {

            if (!req.params.id) {
                throw new Error('Informe os parâmetros exigidos');
            }

            const groupid = req.params.id;
            
            let permissions = await DB().select(['p.permission']).from('usergroups as g').innerJoin('user_permissions as p', 'g.groupid', 'p.groupid').where(
                DB().raw('g.groupid = ? and p.username is null', [groupid])
            );
    
            permissions = permissions.map((item) => {
                return item.permission;
            });
            
            res.json(permissions);
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },

    async save(req, res) {
        try {
            
            if (!req.body.description || !req.body.profile || req.body.internal == null) {
                throw new Error('Informe os campos exigidos.');
            }
        
            let group = req.body;
            let rows;

            // normaliza campos obrigatorios
            group.description = group.description.toUpperCase();

            if (group.id) {
                rows = await DB().from('usergroups').where('groupid', '=', group.id).update({ description: group.description, profile: group.profile, internal: group.internal }, ['groupid', 'description', 'profile', 'internal'], { includeTriggerModifications: true });
            } else {
                const results = await DB().max('groupid', { as: 'id' }).from('usergroups');
                const nextID = results.length ? (results[0].id + 1) : 1;
                
                const newGroup = {
                    groupid: nextID,
                    description: group.description,
                    profile: group.profile,
                    internal: group.internal
                };
                
                rows = await DB().insert(newGroup, ['groupid', 'description', 'profile', 'internal'], { includeTriggerModifications: true }).into('usergroups');
            }
    
            if (rows.length) {
                group.id = rows[0].groupid;
            }
        
            res.json(group);
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },

    async savePermissionsByGroup(req, res) {
        try {

            if (!req.params.id) {
                throw new Error('Informe os campos exigidos.');
            }

            const groupid = req.body.group.id;
            const permissions = req.body.permissions;

            for (let permission of permissions) {
                if (permission.selected) {
                    await DB().from('user_permissions').insert({ groupid: groupid, permission: permission.id, allow: permission.selected });
                } else {
                    await DB().from('user_permissions').where({ groupid: groupid, permission: permission.id }).whereNull('username').delete();
                }
            }
            
            res.json({ message: 'As informações foram salvas com sucesso.' });
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },

    async remove(req, res) {
        const trx = await DB().transaction();
        try {
            
            if (!req.params.id) {
                throw new Error('Informe os campos exigidos.');
            }

            const groupid = req.params.id;

            await DB().transacting(trx).from('user_x_group').where({ groupid: groupid }).delete();
            
            await DB().transacting(trx).from('user_permissions').where({ groupid: groupid }).whereNull('username').delete();
            
            await DB().transacting(trx).from('usergroups').where({ groupid: groupid }).delete();

            trx.commit();
            res.json({ message: 'Grupo de permissões removido com sucesso.' });
        } catch (err) {
            trx.rollback();
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },

    async findGroupModalities(req, res) {
        try {
    
            if (!req.params.id) {
                throw new Error('Inform os parâmetros exigidos');
            }
    
            const groupid = req.params.id;
    
            let permissions = await DB().distinct(['p.permission']).from('user_permissions as p').where(
                DB().raw(`p.groupid = ? and p.permission like 'MODALITY_%' and p.username is null`, [groupid])
            );
    
            permissions = permissions.map((item) => {
                return item.permission.split('_')[1];
            });
    
            res.json(permissions);
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: err.message });
        }
    },

    async saveModality(req, res) {
        try {
            
            if (!req.params.id) {
                throw new Error('Inform os parâmetros exigidos');
            }
    
            const group = req.body.group;
            const modality = req.body.modality;
            
            const results = await DB().select(['id']).from('user_permissions').where({ groupid: group.id }).andWhere({ permission: `MODALITY_${modality.id}` });
    
            if (results.length) {
                await DB().from('user_permissions').where({ id: results[0].id }).delete();
            } else {
                await DB().from('user_permissions').insert({ groupid: group.id, permission: `MODALITY_${modality.id}`, allow: modality.selected });
            }
            
            res.json({ message: 'As informações foram salvas com sucesso.' });
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    }
};
