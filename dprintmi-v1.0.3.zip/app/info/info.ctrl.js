import DB, { database } from '../db.js';
import shortid from 'shortid';
import path from 'path';
import fs from 'fs';

export async function goToHome(req, res) {
    res.redirect('/');
}

export function getInfoCtrl(req, res) {
    // https://stackoverflow.com/questions/57120400/nodejs-pm2-programmatically-restart-process-using-pm2-api
    // https://pm2.keymetrics.io/docs/usage/pm2-api/
    // https://stackoverflow.com/questions/57120400/nodejs-pm2-programmatically-restart-process-using-pm2-api
    // http://knexjs.org/#Installation-log
    // https://www.youtube.com/watch?v=UUvddqElM6g&list=PLJ_KhUnlXUPumHjILbUWY_cskafhR_kXu&index=4
    // https://flaviocopes.com/how-to-sort-array-by-date-javascript/

    // database.open();

    // const results = await DB().select(['USERNAME as username']).table('users');
        
    // res.json(results);

    // const message = { id: shortid.generate(), action: 'SERVER_RESTART' };
    
    // process.send(message);

    const pkg = JSON.parse(fs.readFileSync(path.resolve(`./package.json`), 'utf8'));

    const info = {
        title: pkg.title || '',
        description: pkg.description || '',
        version: pkg.version || '0.0.1'
    };

    console.log('>>>>', info);

    res.json(info);
}