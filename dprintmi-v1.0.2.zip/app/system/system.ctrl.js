import utils from '../utils.js';
import shortid from 'shortid';
import DB, { database } from '../db.js';
import path, { resolve } from 'path';
import fs from 'fs';
import permissionsType from './permissions.js';

export default {

    // Obtem informacoes globais da aplicacao
    async getInfo(req, res) {
        const info = await utils.getPkg();
        res.json(info);
    },

    // Obtem versao do repositorio
    async checkVersion(req, res) {
        const data = await utils.checkVersion();
        res.json(data);
    },

    // Atualiza versao do sistema
    async updateVersion(req, res) {
        try {
            const pkg = await utils.getPkg();

            const version = await utils.checkVersion();

            if (pkg.version >= version['DPrintMI'].version) {
                throw new Error('A aplicação já está utilizando a versão mais recente disponível.');
            }

            await utils.downloadNewVersion(version);
            await utils.sleep(3000);
            
            // se estiver em ambiente dev os arquivos nao serao extraidos e substituidos
            if (process.env.NODE_ENV === 'development' || fs.existsSync(resolve('./README.md')) || fs.existsSync(resolve('./.gitignore'))) {
                console.log('[OK] A aplicação está sendo executada em ambiente de desenvolvimento, por segurança, os arquivos não serão atualizados!');
                
                process.send({ id: shortid.generate(), action: 'RESTART' });
                
                return res.json({ version: version['DPrintMI'].version });
            }

            const srcFile = path.resolve(`./storage/tmp/update/dprintmi-v${version['DPrintMI'].version}.zip`);
            const dstPath = path.resolve('./storage/tmp/update');
            
            await utils.unzipFile(srcFile, dstPath);
            await utils.sleep(1000);
            
            // executar npm install
            await utils.npmInstall(dstPath);
            await utils.sleep(1000);

            // reinicia aplicacao
            process.send({ id: shortid.generate(), action: 'RESTART' });
            
            console.log('[OK] Atualização concluída com sucesso!');
            res.json({ version: version['DPrintMI'].version });
        } catch (err) {
            res.status(400).json({ message: err.message });
        }
    },

    // Verifica se tem solicitacao para recarregar a aplicacao
    checkReload(req, res) {
        if (req.query.id) {
            const pidFile = path.resolve(`./bin/pid/${req.query.id}.json`);
    
            if (fs.existsSync(pidFile)) {
                fs.unlinkSync(pidFile);
            }
        }
        res.json({ reloaded: true });
    },

    // Recarrega a aplicacao
    reload(req, res) {
        const message = { id: shortid.generate(), action: 'RESTART' };
        
        process.send(message);
        
        res.json(message);
    },

    // Obtem configuracoes globais
    async getConfig(req, res) {
        const data = await utils.loadDataFile();
        return res.json(data);
    },

    // Salva as configuracoes criptografadas
    async saveConfig(req, res) {
        const settings = req.body;

        // normaliza os campos necessarios
        settings.database.connection.port = parseInt(settings.database.connection.port) || settings.database.connection.port;
    
        const data = await utils.saveDataFile(settings);
        return res.json(data);
    },

    // Valida conexao com banco de dados configurado
    async checkDBConn(req, res) {
        const settings = req.body;

        // normaliza os campos necessarios
        settings.database.connection.port = parseInt(settings.database.connection.port) || settings.database.connection.port;
    
        const status = await database.check(settings);
        if (!status.checked) {
            return res.status(400).json(status);
        }
    
        return res.json(status);
    },

    // Obtem arvore de permissoes do sistema
    async getPermissions(req, res) {
        res.json(permissionsType);
    }
};
