import moment from 'moment';
import utils from '../utils.js';
import DB from '../db.js';

export default {

    // Obtem lista de modalidades cadastradas
    async findAll(req, res) {
        try {
            const modalities = await DB().distinct(['id', 'description']).table('modalities').orderBy(['description']);
            
            res.json(modalities);
        } catch (err) {
            console.log(err);
            res.status(400).json({ message: err.message });
        }
    },
};

export async function findAllModalitiesCtrl(req, res) {
    try {
        const modalities = await DB().distinct(['id', 'description']).table('modalities').orderBy(['description']);
        
        res.json(modalities);
    } catch (err) {
        console.log(err);
        res.status(400).json({ message: err.message });
    }
}
