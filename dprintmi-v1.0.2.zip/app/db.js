import knex from 'knex';
import now from 'performance-now';
import utils from './utils.js';
import migrations from './migrations/index.js';

let DBConn = null, count = 0, times = {};

const onQueryRequest = function(query) {
    const uid = query.__knexQueryUid;

    times[uid] = {
        position: count,
        query,
        startTime: now(),
        finished: false,
    };
    
    count = count + 1;
};

const onQueryResponse = function(response, query) {
    const uid = query.__knexQueryUid;
    times[uid].endTime = now();
    times[uid].finished = true;
    const position = times[uid].position;

    printIfPossible(uid);
    printQueriesAfterGivenPosition(position);
};

const printQueryWithTime = (uid) => {
    const { startTime, endTime, query } = times[uid];
    const elapsedTime = endTime - startTime;

    console.log('SQL:', query.sql, `[${query.bindings ? query.bindings.join(',') : ''}] => Time: ${elapsedTime.toFixed(3)} ms.`);
    delete times[uid];
};

const printIfPossible = (uid) => {
    const { position } = times[uid];

    const previousTimeUid = Object.keys(times).find(key => times[key].position === position - 1);

    if (!previousTimeUid) {
        printQueryWithTime(uid);
    }
};

const printQueriesAfterGivenPosition = (position) => {
    const nextTimeUid = Object.keys(times).find(key => times[key].position === position + 1);

    if (nextTimeUid && times[nextTimeUid].finished) {
        const nextPosition = times[nextTimeUid].position;
        printQueryWithTime(nextTimeUid);
        printQueriesAfterGivenPosition(nextPosition);
    }
};

export const database = {
    open: async function() {
        try {
            const settings = await utils.loadDataFile();
            
            if (!DBConn) {
                
                if (settings.database.client === 'mssql') {
                    settings.database.connection.useNullAsDefault = settings.database.connection.useNullAsDefault || true;
                    settings.database.connection.encrypt = settings.database.encrypt || false;
                }
    
                DBConn = knex(settings.database).on('query', onQueryRequest).on('query-response', onQueryResponse);

                // load migrations
                await migrations(DBConn);
            }
            
            return DBConn;
        } catch (err) {
            return null;
        }
    },

    check: async function(settings) {
        try {
            
            if (settings.database.client === 'mssql') {
                
                settings.database.connection.useNullAsDefault = settings.database.connection.useNullAsDefault || true;
                settings.database.connection.encrypt = settings.database.encrypt || false;
                
                DBConn = knex(settings.database).on('query', onQueryRequest).on('query-response', onQueryResponse);
                
                const data = await DBConn.raw("select 'CONNECTED' as status");
                
                if (data.length && data[0].status === 'CONNECTED') {
                    // const results = await DBConn.select(['USERNAME as username']).table('users');
                    // const results = await DBConn.raw("select username from users");
    
                    return { checked: true, message: 'A conexão com banco de dados foi realizada com sucesso!' };
                }
            }

            if (settings.database.client === 'pg') {
                DBConn = knex(settings.database).on('query', onQueryRequest).on('query-response', onQueryResponse);
                
                const data = await DBConn.raw("select 'CONNECTED' as status");
                
                if (data.length && data[0].status === 'CONNECTED') {
                    // DBConn.raw('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"');
    
                    return { checked: true, message: 'A conexão com banco de dados foi realizada com sucesso!' };
                }
            }

            throw new Error('O driver do banco de dados não foi informado ou não é suportado atualmente.');
        } catch (err) {
            settings.database.checked = false;
            utils.saveDataFile(settings);
            return { checked: false, message: err.message };
        }
    },
}

export default function() {
    return DBConn;
};
