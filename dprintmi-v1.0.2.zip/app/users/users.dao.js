import moment from 'moment';
import utils from '../utils.js';
import DB from '../db.js';

export default {

    // Verifica se user existe
    async userExists(username) {
        return await DB().select(['username']).from('users').whereRaw('upper(username) = upper(?)', [username]);
    },

    // Obtem usuario pelo username passado como parametro
    async findUserByUsername(username) {
        const rows = await DB().select(['u.username', 'u.fullname', 'u.email', 'u.userstatus', 'u.usertype', 'u.profile as group_id', 'ug.description as group_description']).table('users as u').leftOuterJoin('usergroups as ug', 'u.profile', 'ug.groupid').whereRaw('lower(u.username) = lower(?)', [username]);
        return rows.length > 0 ? rows[0] : null;
    },

    // Obtem os grupos do usuario passado como parametro
    async findGroupsByUser(user) {
        return await DB().select(['ug.groupid as id', 'g.description as description']).from('usergroups as g').innerJoin('user_x_group as ug', 'ug.groupid', 'g.groupid').whereRaw('lower(ug.username) = lower(?)', [user.username]);
    },

    // Obtem todas as permissoes do usuario passado como parametro
    async findPermissionsByUser(user) {
        
        let permissions = await DB().distinct(['p.permission']).from('user_x_group as ug').innerJoin('usergroups as g', 'ug.groupid', 'g.groupid').innerJoin('user_permissions as p', 'ug.groupid', 'p.groupid').where(
            DB().raw('UPPER(ug.username) = ? and p.username is null and p.permission not in (select distinct up.permission from user_permissions as up where up.username = ug.username)', [user.username])
        ).unionAll(function() {
            this.select(['p.permission']).from('user_permissions as p').where(
                DB().raw(`UPPER(p.username) = ? and p.allow = '1'`, [user.username])
            );
        });

        permissions = permissions.map((item) => {
            return item.permission;
        });

        if (utils.isAdmin(user)) {
            permissions.push('ALL');
        }

        return permissions;
    },

    // Obtem todas as permissoes do usuario passado como parametro
    async findPermissionsByUsername(username) {
        const user = await this.findUserByUsername(username);

        let permissions = await this.findPermissionsByUser(user);

        return permissions;
    },

    // Remove usuario e suas associacoes
    async remove(user) {
        const trx = await DB().transaction();
        try {

            await DB().transacting(trx).from('user_x_group').where({ username: user.username }).delete();
            await DB().transacting(trx).from('user_permissions').where({ username: user.username }).delete();
            await DB().transacting(trx).from('users').where({ username: user.username }).delete();
            
            trx.commit();
        } catch (err) {
            trx.rollback();
            throw err;
        }
    },
};
