export default {

    // Renderiza a pagina inicial da API
    home(req, res) {
        console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Foi:');
        res.render('index', { version: '1.0.0' });
    },
    
    // Renderiza a pagina index do frontend
    goToHome(req, res) {
        res.redirect('/');
    }
};
