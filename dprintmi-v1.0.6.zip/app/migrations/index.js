import * as migrations from './database.js';

export default async function(DB) {
    await migrations.create_table_dicom_devices(DB);
    await migrations.alter_table_users_add_column_profile(DB);
    await migrations.alter_table_users_add_column_user_type(DB);
    await migrations.create_table_user_permissions(DB);
    await migrations.create_table_modalities(DB);
    await migrations.alter_table_usergroups_add_column_profile(DB);
    await migrations.alter_table_usergroups_add_column_internal(DB);

    await migrations.insert_default_users(DB);
}
