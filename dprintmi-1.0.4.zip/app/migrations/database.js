import utils from '../utils.js';

export async function create_table_dicom_devices(DB) {
    try {
        const driver = DB.connection().client.config.client;

        const hasTable = await DB.schema.hasTable('dicomdevices');
        
        if (!hasTable) {
            const table = { dicomdevices: 'dicomdevices', id: 'id', name: 'name', aetitle: 'aetitle', modality: 'modality', parentid: 'parentid' };

            if (driver === 'mssql') {
                for (const prop in table) {
                    table[prop] = table[prop].toUpperCase();
                }
            }
            
            return DB.schema.createTable(table['dicomdevices'], (t) => {
                t.increments(table['id']).primary();
                t.string(table['name'], 25);
                t.string(table['aetitle'], 25);
                t.string(table['modality'], 10);
                t.integer(table['parentid']);
            });
        }
    } catch (err) {
        console.log('[X] Erro de migracao:', err);
    }
};

export async function alter_table_users_add_column_profile(DB) {
    const driver = DB.connection().client.config.client;

    const hasTable = await DB.schema.hasTable('users');
    if (!hasTable) {
        return;
    }

    const hasProfileColumn = await DB.schema.hasColumn('users', 'profile');

    if (!hasProfileColumn) {
        if (driver === 'mssql') {
            return DB.schema.table('users', async(table) => {
                await table.integer('PROFILE');
                await DB.from('users').update({ profile: null });
            });
        } else {
            return DB.schema.table('users', async(table) => {
                await table.integer('profile');
                await DB.from('users').update({ profile: null });
            });
        }
    }
}

export async function alter_table_users_add_column_user_type(DB) {
    const driver = DB.connection().client.config.client;

    const hasTable = await DB.schema.hasTable('users');
    if (!hasTable) {
        return;
    }

    // usertype = DEVELOPER, SUPPORT OU USER
    const hasUserTypeColumn = await DB.schema.hasColumn('users', 'usertype');

    if (!hasUserTypeColumn) {
        if (driver === 'mssql') {
            return DB.schema.table('users', async(table) => {
                await table.string('USERTYPE', 25);
            }).then(async () => {
                return await DB.from('users').update({ usertype: 'USER' });
            });
        } else {
            return DB.schema.table('users', async(table) => {
                await table.string('usertype', 25);
            }).then(async () => {
                return await DB.from('users').update({ usertype: 'USER' });
            });
        }
    }
}

export async function create_table_user_permissions(DB) {
    const driver = DB.connection().client.config.client;

    const hasUserPermissionsTable = await DB.schema.hasTable('user_permissions');

    if (!hasUserPermissionsTable) {
        const table = { user_permissions: 'user_permissions', id: 'id', groupid: 'groupid', username: 'username', permission: 'permission', allow: 'allow' };
    
        if (driver === 'mssql') {
            for (const prop in table) {
                table[prop] = table[prop].toUpperCase();
            }
        }

        return DB.schema.createTable(table['user_permissions'], (t) => {
            t.increments(table['id']).primary();
            t.integer(table['groupid']);
            t.string(table['username'], 45);
            t.string(table['permission'], 45);
            t.boolean(table['allow']).defaultTo(true);
        });
    }
}

export async function create_table_modalities(DB) {
    const driver = DB.connection().client.config.client;

    const hasModalitiesTable = await DB.schema.hasTable('modalities');

    if (!hasModalitiesTable) {
        const table = { modalities: 'modalities', id: 'id', description: 'description' };
    
        if (driver === 'mssql') {
            for (const prop in table) {
                table[prop] = table[prop].toUpperCase();
            }
        }

        return DB.schema.createTable(table['modalities'], (t) => {
            t.string(table['id'], 10).primary();
            t.string(table['description'], 64);
        }).then(function() {
            return DB('modalities').insert([
                { id: 'CR', description: 'Radiografia Computadorizada' },
                { id: 'DR', description: 'Radiografia Digital' },
                { id: 'MG', description: 'Mamografia' },
                { id: 'CT', description: 'Tomografia Computadorizada' },
                { id: 'PT', description: 'Tomografia (PET)' },
                { id: 'MR', description: 'Ressonância Magnética' },
                { id: 'US', description: 'Ultrassom' },
                { id: 'ES', description: 'Endoscopia' },
                { id: 'NM', description: 'Medicina Nuclear' },
                { id: 'OT', description: 'Outro' }
            ]);
        });
    }
}

export async function alter_table_usergroups_add_column_profile(DB) {
    const driver = DB.connection().client.config.client;

    const hasTable = await DB.schema.hasTable('usergroups');
    if (!hasTable) {
        return;
    }

    const hasProfileColumn = await DB.schema.hasColumn('usergroups', 'profile');

    if (!hasProfileColumn) {
        if (driver === 'mssql') {
            return DB.schema.table('usergroups', async(table) => {
                table.string('PROFILE', 35);
            }).then(function() {
                return DB.from('usergroups').update({ profile: 'USER' });
            });
        } else {
            return DB.schema.table('usergroups', async(table) => {
                table.string('profile', 35);
            }).then(function() {
                return DB.from('usergroups').update({ profile: 'USER' });
            });
        }
    }
}

export async function alter_table_usergroups_add_column_internal(DB) {
    const driver = DB.connection().client.config.client;

    const hasTable = await DB.schema.hasTable('usergroups');
    if (!hasTable) {
        return;
    }

    const hasInternalColumn = await DB.schema.hasColumn('usergroups', 'internal');

    if (!hasInternalColumn) {
        if (driver === 'mssql') {
            return DB.schema.table('usergroups', async(table) => {
                table.boolean('INTERNAL');
            }).then(function() {
                return DB.from('usergroups').update({ internal: false });
            });
        } else {
            return DB.schema.table('usergroups', async(table) => {
                table.boolean('internal');
            }).then(function() {
                return DB.from('usergroups').update({ internal: false });
            });
        }
    }
}

export async function insert_default_users(DB) {
    try {
        
        const hasTable = await DB.schema.hasTable('users');
        
        if (hasTable) {

            // cria usuario developer se nao existir
            let rows = await DB('users').select('username').where({ username: 'DEVELOPER' });
            if (!rows.length) {
                await DB('users').insert({ username: 'DEVELOPER', fullname: 'MASTER DEVELOPER', pwd: utils.sha256('WTT@SOLUTION'), email: 'desenvolvimento@wtt.com.br', userstatus: 'ACTIVE', profile: null, usertype: 'DEVELOPER' }, [], { includeTriggerModifications: true });
            }
            
            // cria usuario support se nao existir
            rows = await DB('users').select('username').where({ username: 'MASTER' });
            if (!rows.length) {
                await DB('users').insert({ username: 'MASTER', fullname: 'MASTER SUPORTE', pwd: utils.sha256('WTTSOLUTION'), email: 'suporte@wtt.com.br', userstatus: 'ACTIVE', profile: null, usertype: 'SUPPORT' }, [], { includeTriggerModifications: true });
            }
            
            // cria usuario comum se nao existir (apenas para testes)
            rows = await DB('users').select('username').where({ username: 'ALAIN' });
            if (!rows.length) {
                await DB('users').insert({ username: 'ALAIN', fullname: 'ALAIN CHUCRUTZ', pwd: utils.sha256('ALAIN'), email: 'alain@wtt.com.br', userstatus: 'ACTIVE', profile: null, usertype: 'USER' }, [], { includeTriggerModifications: true });
            }
        }
        
        return;
    } catch (err) {
        console.log('[X] Erro de migracao:', err);
    }
};
