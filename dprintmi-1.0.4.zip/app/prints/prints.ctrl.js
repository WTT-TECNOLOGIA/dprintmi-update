import moment from 'moment';
import utils from '../utils.js';
import DB from '../db.js';

export default {

    // Obtem impressos nao reconhecidos
    prints(req, res) {

        res.json([]);
    },
};
